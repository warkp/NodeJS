#IMPORTANT

#BEFORE RUNNING ANY APPLICATION RUN npm install TO INSTALL ALL LIBRARIES FROM PACKAGE.JSON

Q. When is it a good idea to not use NodeJs? Why? 

Ans. 

1. Dealing with relational database is a pain if you are using Node.

2. Node.js is not suited for CPU-intensive tasks. It is suited for I/O stuff only (like web servers).

-- Go to project folder and run npm install
-- To run tests go to project folder and type npm test
-- to run http server go to project folder and type node server.js
-- hit the api through postman or browser

#APPLICATION DETAIL

APPLICATION DETAIL - 
1. marcoPolo   - return the series with success true or false.
2. userStory  - read the invoices from file and write the result in file - output_user_story_1.txt.
3. topSecret       - read the code from file and write the secret code in file - output_top_secret1.txt

